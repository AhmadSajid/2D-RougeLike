﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class filling : MonoBehaviour
{
    public static filling instance;

    // Start is called before the first frame update
    void Start()
    {
        instance = this;
        GetComponent<Image>().fillAmount = 1f;
    }

    // Update is called once per frame
    void Update()
    {
        if (GetComponent<Image>().fillAmount > 0f)
        {

        GetComponent<Image>().fillAmount -= 0.10f * Time.deltaTime;
        }

        if (GetComponent<Image>().fillAmount <= 0f)
        {
            GetComponent<Image>().fillAmount = 0f;
            PlayerController.instance.powerup = false;
            PlayerController.instance.power_shield.SetActive(false);

        }
     }

    public void getfill()
    {
        GetComponent<Image>().fillAmount = 1f;
    }

}
