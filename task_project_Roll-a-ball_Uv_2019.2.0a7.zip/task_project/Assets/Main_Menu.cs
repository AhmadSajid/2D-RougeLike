﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Main_Menu : MonoBehaviour
{
    public static Main_Menu instance;
    public int lvl = 0;

    // Start is called before the first frame update
    void Start()
    {
        instance = this; 
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void OnSelectlvl(int l)
    {
        lvl = l;
        SceneManager.LoadScene("Roll-a-ball");
    }
}
