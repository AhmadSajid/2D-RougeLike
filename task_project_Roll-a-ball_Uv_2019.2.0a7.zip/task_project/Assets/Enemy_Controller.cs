﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy_Controller : MonoBehaviour
{
    public static Enemy_Controller instance;
    public GameObject enemy;                // The enemy prefab to be spawned.
    public float spawnTime = 3f;            // How long between each spawn.
    public Transform[] spawnPoints;         // An array of the spawn points this enemy can spawn from.

    // Start is called before the first frame update
    void Start()
    {
        instance = this;

        // Call the Spawn function after a delay of the spawnTime and then continue to call after the same amount of time.
        InvokeRepeating("Spawn", spawnTime, spawnTime);
        if (Main_Menu.instance.lvl == 1)
        {
            Invoke("Cancel_Invoke", 6.1f);
        }
        if (Main_Menu.instance.lvl == 2)
        {
            Invoke("Cancel_Invoke", 12.1f);
        }

    }

    void Spawn()
    {
        // Find a random index between zero and one less than the number of spawn points.
        int spawnPointIndex = Random.Range(0, spawnPoints.Length);

        // Create an instance of the enemy prefab at the randomly selected spawn point's position and rotation.
        Instantiate(enemy, spawnPoints[spawnPointIndex].position, spawnPoints[spawnPointIndex].rotation);
    }

    void Cancel_Invoke()
    {
        CancelInvoke();
    }

    // Update is called once per frame
    void Update()
    {
        
    }



}
