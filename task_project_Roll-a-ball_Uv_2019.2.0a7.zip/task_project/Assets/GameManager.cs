﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{

    public static GameManager instance;

    public GameObject menupanel;
    public GameObject gameplaypanel;
    public GameObject gameoverpanel;
    public GameObject winpanel;
    public Text score_txt;

    public Button resartbtn;
    public Button nextlvlbtn;

    public GameObject lvlgmbt;
    public GameObject power_up;

    // Start is called before the first frame update
    void Start()
    {
        instance = this;


        lvlgmbt.transform.GetChild(Main_Menu.instance.lvl-1).gameObject.SetActive(true); ;

        if(Main_Menu.instance.lvl==3)
        {
            GameObject obj = Instantiate(power_up, new Vector3(Random.Range(-25f,25f),1f,Random.Range(-25f,25f)),Quaternion.identity);
        }

    }

    // Update is called once per frame
    void Update()
    {
        score_txt.text = "Score: " + PlayerController.instance.count;

        if (PlayerController.instance.count >= 12 && Main_Menu.instance.lvl==1)
        {
            OnWin();

        }
        if (PlayerController.instance.count >= 60 && Main_Menu.instance.lvl == 2)
        {
            OnWin();

        }
        if (PlayerController.instance.count >= 60 && Main_Menu.instance.lvl == 3)
        {
            OnWin();

        }

    }

    void OnWin()
    {
        winpanel.SetActive(true);
        GameManager.instance.resartbtn.interactable = true;
        GameManager.instance.nextlvlbtn.interactable = true;

        PlayerController.instance.rb.isKinematic = true;
    }

    public void OnRestart()
    {
        SceneManager.LoadScene("Roll-a-ball");
    }

    public void OnNext()
    {
        Main_Menu.instance.lvl += 1;
        SceneManager.LoadScene("Roll-a-ball");
        
    }

}
