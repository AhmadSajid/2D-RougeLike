﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : MonoBehaviour
{
    public static Enemy instance;
    public Transform player;
 public float MoveSpeed = 4;
    public float MaxDist = 10;
    public float MinDist = 0.5f;

    public bool start = false;

    // Start is called before the first frame update
    void Start()
    {
        instance = this;
        player = GameObject.Find("Player").transform;
        Invoke("start_moving",3f);
    }

    // Update is called once per frame
    void Update()
    {
        if (start && !GameManager.instance.winpanel.activeSelf && !GameManager.instance.gameoverpanel.activeSelf)
        {
            transform.LookAt(player);

            if (Vector3.Distance(transform.position, player.position) >= MinDist)
            {
                if(PlayerController.instance.powerup)
                {
                    transform.position -= transform.forward * MoveSpeed * Time.deltaTime;
                }
                else
                {

                    transform.position += transform.forward * MoveSpeed * Time.deltaTime;
                }


                if (Vector3.Distance(transform.position, player.position) <= MaxDist)
                {
                    //Here Call any function U want Like Shoot at here or something
                }

            }
        }
    }

    void start_moving()
    {
        start = true;
    }
}
